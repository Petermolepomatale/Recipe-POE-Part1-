﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            bool exit = false;

            Dictionary<string, Action> actions = new Dictionary<string, Action>
            {
                { "1", recipe.EnterRecipeDetails },
                { "2", recipe.ViewRecipe },
                { "3", recipe.ScaleRecipe },
                { "4", recipe.ResetQuantities },
                { "5", recipe.ClearRecipe },
                { "6", () => exit = true }
            };

            while (!exit)
            {
                Console.WriteLine("╔════════════════════════════════════════╗");
                Console.WriteLine("║                Menu                    ║");
                Console.WriteLine("╚════════════════════════════════════════╝");            //ASCII art 
                Console.WriteLine("1. Enter Recipe Details");
                Console.WriteLine("2. View Recipe");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear Recipe");
                Console.WriteLine("6. Exit");
                Console.WriteLine();
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();
                Console.WriteLine("------------------------------------------");

                if (actions.ContainsKey(choice))
                {
                    actions[choice].Invoke();
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                }
            }
        }
    }

    class Recipe
    {
        private string[] ingredients;
        private string[] steps;
        private double[] originalQuantities;

        public void EnterRecipeDetails()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              Ingredients:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());
            ingredients = new string[ingredientCount];
            originalQuantities = new double[ingredientCount];
            Console.WriteLine();

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                string name = Console.ReadLine();
                Console.WriteLine();

                Console.Write($"Enter quantity of {name}: ");
                double quantity = double.Parse(Console.ReadLine());
                originalQuantities[i] = quantity;
                Console.WriteLine();

                Console.Write($"Enter unit of measurement for {name}: ");
                string unit = Console.ReadLine();

                ingredients[i] = $"{quantity} {unit} of {name}";
                Console.WriteLine("------------------------------------------");
            }
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              Steps:                    ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            Console.WriteLine();
            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());
            steps = new string[stepCount];
            Console.WriteLine();

            for (int i = 0; i < stepCount; i++)
            {
                Console.Write($"Enter step {i + 1} description: ");
                steps[i] = Console.ReadLine();

            }

            Console.WriteLine("Recipe details entered successfully.");
            Console.WriteLine("------------------------------------------");
        }

        public void ViewRecipe()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ViewRecipe:               ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            if (ingredients == null || steps == null)
            {
                Console.WriteLine("Recipe is empty. Please enter recipe details first.");
                return;
            }

            Console.WriteLine("Recipe:");

            Console.WriteLine("\nIngredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
                Console.WriteLine("------------------------------------------");
            }
        }

        public void ScaleRecipe()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ScaleRecipe:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            if (ingredients == null)
            {
                Console.WriteLine("Recipe is empty. Please enter recipe details first.");
                return;
            }

            Console.Write("Enter scale factor (0.5, 2, or 3): ");
            double scaleFactor = double.Parse(Console.ReadLine());

            for (int i = 0; i < ingredients.Length; i++)
            {
                string[] parts = ingredients[i].Split(' ');
                double quantity = double.Parse(parts[0]) * scaleFactor;
                ingredients[i] = $"{quantity} {parts[1]} of {string.Join(' ', parts[3..])}";
            }

            Console.WriteLine("Recipe scaled successfully.");
            Console.WriteLine("------------------------------------------");
        }

        public void ResetQuantities()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ResetQuantities:          ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            if (originalQuantities != null)
            {
                for (int i = 0; i < originalQuantities.Length; i++)
                {

                    string[] parts = ingredients[i].Split(' ');
                    ingredients[i] = $"{originalQuantities[i]} {parts[1]} of {string.Join(' ', parts[3..])}";
                }

                Console.WriteLine("Quantities reset to original values.");
                Console.WriteLine("------------------------------------------");
            }
            else
            {
                Console.WriteLine("No recipe details entered yet.");
                Console.WriteLine("------------------------------------------");
            }
        }

        public void ClearRecipe()
        {
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ClearRecipe:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");   //ASCII art for the design 
            ingredients = null;
            steps = null;
            originalQuantities = null;
            Console.WriteLine("Recipe cleared.");
            Console.WriteLine("------------------------------------------");
        }
    }
}

