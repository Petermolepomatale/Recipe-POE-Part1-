﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe(); // Instantiate Recipe object
            bool exit = false;

            // Dictionary to map user inputs to corresponding actions
            Dictionary<string, Action> actions = new Dictionary<string, Action>
            {
                { "1", recipe.EnterRecipeDetails }, // Enter recipe details
                { "2", recipe.ViewRecipe }, // View recipe
                { "3", recipe.ScaleRecipe }, // Scale recipe
                { "4", recipe.ResetQuantities }, // Reset quantities
                { "5", recipe.ClearRecipe }, // Clear recipe
                { "6", () => exit = true } // Exit
            };

            // Main loop to display menu and process user input
            while (!exit)
            {
                // Displaying Menu with decorative border
                Console.WriteLine("╔════════════════════════════════════════╗");
                Console.WriteLine("║                Menu                    ║");
                Console.WriteLine("╚════════════════════════════════════════╝");
                Console.WriteLine("1. Enter Recipe Details");
                Console.WriteLine("2. View Recipe");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear Recipe");
                Console.WriteLine("6. Exit");
                Console.WriteLine();
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine(); // Read user choice
                Console.WriteLine("------------------------------------------");

                if (actions.ContainsKey(choice))
                {
                    actions[choice].Invoke(); // Invoke corresponding action
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                }
            }
        }
    }

    class Recipe
    {
        private string[] ingredients;
        private string[] steps;
        private double[] originalQuantities;

        // Method to enter recipe details
        public void EnterRecipeDetails()
        {
            // Displaying Ingredients heading with decorative border
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              Ingredients:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine()); // Read number of ingredients
            ingredients = new string[ingredientCount]; // Initialize ingredients array
            originalQuantities = new double[ingredientCount]; // Initialize originalQuantities array
            Console.WriteLine();

            // Loop to input each ingredient
            for (int i = 0; i < ingredientCount; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                string name = Console.ReadLine();
                Console.WriteLine();

                Console.Write($"Enter quantity of {name}: ");
                double quantity = double.Parse(Console.ReadLine());
                originalQuantities[i] = quantity; // Store original quantity
                Console.WriteLine();

                Console.Write($"Enter unit of measurement for {name}: ");
                string unit = Console.ReadLine();

                ingredients[i] = $"{quantity} {unit} of {name}";
                Console.WriteLine("------------------------------------------");
            }

            // Displaying Steps heading with decorative border
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              Steps:                    ║");
            Console.WriteLine("╚════════════════════════════════════════╝");
            Console.WriteLine();
            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine()); // Read number of steps
            steps = new string[stepCount]; // Initialize steps array
            Console.WriteLine();

            // Loop to input each step
            for (int i = 0; i < stepCount; i++)
            {
                Console.Write($"Enter step {i + 1} description: ");
                steps[i] = Console.ReadLine();
            }

            Console.WriteLine("Recipe details entered successfully.");
            Console.WriteLine("------------------------------------------");
        }

        // Method to view recipe details
        public void ViewRecipe()
        {
            // Displaying View Recipe heading with decorative border
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ViewRecipe:               ║");
            Console.WriteLine("╚════════════════════════════════════════╝");

            if (ingredients == null || steps == null)
            {
                Console.WriteLine("Recipe is empty. Please enter recipe details first.");
                return;
            }

            Console.WriteLine("Recipe:");

            // Displaying Ingredients
            Console.WriteLine("\nIngredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }

            // Displaying Steps
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
                Console.WriteLine("------------------------------------------");
            }
        }

        // Method to scale recipe
        public void ScaleRecipe()
        {
            // Displaying Scale Recipe heading with decorative border
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ScaleRecipe:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");

            if (ingredients == null)
            {
                Console.WriteLine("Recipe is empty. Please enter recipe details first.");
                return;
            }

            Console.Write("Enter scale factor (0.5, 2, or 3): ");
            double scaleFactor = double.Parse(Console.ReadLine()); // Read scale factor

            // Loop to scale each ingredient
            for (int i = 0; i < ingredients.Length; i++)
            {
                string[] parts = ingredients[i].Split(' ');
                double quantity = double.Parse(parts[0]) * scaleFactor;
                ingredients[i] = $"{quantity} {parts[1]} of {string.Join(' ', parts[3..])}";
            }

            Console.WriteLine("Recipe scaled successfully.");
            Console.WriteLine("------------------------------------------");
        }

        // Method to reset quantities to original values
        public void ResetQuantities()
        {
            // Displaying Reset Quantities heading with decorative border
            Console.WriteLine("╔══ ═════════════════════════════════════╗");
            Console.WriteLine("║              ResetQuantities:          ║");
            Console.WriteLine("╚════════════════════════════════════════╝");

            if (originalQuantities != null)
            {
                // Loop to reset quantities to original values
                for (int i = 0; i < originalQuantities.Length; i++)
                {
                    string[] parts = ingredients[i].Split(' ');
                    ingredients[i] = $"{originalQuantities[i]} {parts[1]} of {string.Join(' ', parts[3..])}";
                }

                Console.WriteLine("Quantities reset to original values.");
                Console.WriteLine("------------------------------------------");
            }
            else
            {
                Console.WriteLine("No recipe details entered yet.");
                Console.WriteLine("------------------------------------------");
            }
        }

        // Method to clear recipe details
        public void ClearRecipe()
        {
            // Displaying Clear Recipe heading with decorative border
            Console.WriteLine("╔════════════════════════════════════════╗");
            Console.WriteLine("║              ClearRecipe:              ║");
            Console.WriteLine("╚════════════════════════════════════════╝");

            ingredients = null; // Clear ingredients array
            steps = null; // Clear steps array
            originalQuantities = null; // Clear originalQuantities array

            Console.WriteLine("Recipe cleared.");
            Console.WriteLine("------------------------------------------");
        }
    }
}